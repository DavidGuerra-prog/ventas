<?php
    $insLogin->cerrarSesionControlador();